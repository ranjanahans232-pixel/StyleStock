package com.stylesstock.stylestock.config;

import com.stylesstock.stylestock.model.*;
import com.stylesstock.stylestock.repository.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;

/**
 * Converts the IDs posted by HTML select controls into their corresponding JPA entities.
 */
@Configuration
public class EntityConverters {
    @Bean
    Converter<String, Brand> brandConverter(BrandRepository repository) {
        return id -> id == null || id.isBlank() ? null : repository.findById(Long.valueOf(id)).orElse(null);
    }
    @Bean
    Converter<String, Category> categoryConverter(CategoryRepository repository) {
        return id -> id == null || id.isBlank() ? null : repository.findById(Long.valueOf(id)).orElse(null);
    }
    @Bean
    Converter<String, Supplier> supplierConverter(SupplierRepository repository) {
        return id -> id == null || id.isBlank() ? null : repository.findById(Long.valueOf(id)).orElse(null);
    }
    @Bean
    Converter<String, Product> productConverter(ProductRepository repository) {
        return id -> id == null || id.isBlank() ? null : repository.findById(Long.valueOf(id)).orElse(null);
    }
    @Bean
    Converter<String, DistributionCentre> centreConverter(DistributionCentreRepository repository) {
        return id -> id == null || id.isBlank() ? null : repository.findById(Long.valueOf(id)).orElse(null);
    }
}
