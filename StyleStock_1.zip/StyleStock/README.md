# StyleStock — Clothing Inventory Management System

**Course:** CPAN-228 Web Application Development  
**Project type:** Choose Your Own Adventure — E-Commerce Platform domain  
**Status:** Working Spring Boot prototype / academic project starter

> Before submitting, replace the team placeholders below, confirm the project requirements with your instructor, run the application on your own computer, and push the final version to your group's GitHub repository. Do not claim features you have not tested.

## Team
- Group name: StockSmart Developers
- Member 1: [Full name] — [Student ID if required] — [Role]
- Member 2: [Full name] — [Student ID if required] — [Role]
- Member 3: [Full name] — [Student ID if required] — [Role]

## Overview
StyleStock is a small clothing inventory management web application. It helps staff maintain a product catalogue, see stock levels at distribution centres, identify low-stock items, and create stock-transfer requests.

## Problem statement
Clothing inventory can be spread across product types, sizes, colours, suppliers, and storage locations. Tracking this information manually can lead to inaccurate counts and delayed restocking. StyleStock provides one web interface for organizing product details and viewing stock status.

## Motivation
The project applies Spring Boot, MVC controllers, Thymeleaf templates, JPA entities, repositories, form validation, and authentication to a practical inventory workflow.

## Main features implemented
- Login-protected application pages using Spring Security.
- Dashboard metrics for products, distribution centres, low-stock items, and transfer requests.
- Product listing, search by name/SKU, create, edit, and delete.
- Inventory overview with low-stock indicators.
- Create and list stock-transfer requests.
- H2 in-memory database with sample seed data.
- Responsive HTML/CSS interface.

## Technology stack
- Java 17
- Spring Boot 3.4.5
- Spring Web / MVC
- Thymeleaf
- Spring Data JPA
- Spring Security
- Jakarta Bean Validation
- H2 in-memory database
- Maven

## Domain entities
1. **AppUser** — full name, email, password hash, role, active status.
2. **Brand** — brand name, description, active status.
3. **Category** — category name and description.
4. **Product** — name, SKU, size, colour, unit price, brand, category, supplier.
5. **Supplier** — name, email, phone.
6. **DistributionCentre** — name, address, city.
7. **Inventory** — product, centre, quantity, reorder level.
8. **StockTransfer** — product, source centre, destination centre, quantity, date, status.

## Relationships
- One brand can be associated with many products.
- One category can contain many products.
- One supplier can supply many products.
- One product can have inventory records at multiple centres.
- One distribution centre can store many inventory records.
- Each stock transfer references one product, one source centre, and one destination centre.

See `docs/ER-DIAGRAM.md` for the Mermaid ER diagram and `docs/WIREFRAMES.md` for the four required UI wireframe descriptions.

## Run the application
1. Install JDK 17 or later and Maven (or use the Maven wrapper if your team adds one).
2. Extract the ZIP and open the `StyleStock` folder in IntelliJ IDEA or VS Code.
3. In a terminal opened at the project root, run:

   ```bash
   mvn spring-boot:run
   ```

4. Open `http://localhost:8080`.
5. Log in with one of the local demonstration accounts below.

### Local demo accounts
- Admin username: `admin`
- Admin password: `StyleStock123!`
- Staff username: `staff`
- Staff password: `Staff123!`

These are demo credentials for local coursework only. Do not use them in a public production deployment.

### H2 database console
- URL: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:stylestockdb`
- Username: `sa`
- Password: leave blank

The database is in-memory, so sample and entered records are reset when the application restarts.

## Project structure
```text
StyleStock/
├── docs/
│   ├── ER-DIAGRAM.md
│   └── WIREFRAMES.md
├── src/main/java/com/stylesstock/stylestock/
│   ├── config/
│   ├── controller/
│   ├── model/
│   └── repository/
├── src/main/resources/
│   ├── static/css/style.css
│   ├── templates/
│   └── application.properties
└── pom.xml
```

## Known limitations / future improvements
- User accounts are configured in memory for the demonstration; `AppUser` is a domain entity, not the active login provider.
- Transfer requests are recorded but do not yet automatically deduct/add inventory quantities or support approval workflow.
- Brand, category, supplier, and distribution-centre management screens can be added in a future iteration.
- H2 is used for easy local setup; a persistent database can be configured later.

## Repository
GitHub URL: [Paste your group's GitHub repository link here]

## Academic integrity reminder
This is a project starter/example. Every group member should understand the code, test the app, make their own contributions, and follow the instructor's rules on collaboration and AI assistance.
